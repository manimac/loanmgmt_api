const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const MODELS = require("../models");
const Model = MODELS.approvals;
const profileModel = MODELS.profile;
const profilehistoryModel = MODELS.profilehistory;
const loanModel = MODELS.loan;
const loanhistoryModel = MODELS.loanhistory;
const investmentModel = MODELS.investment;
const repaymenthistoryModel = MODELS.repaymenthistory;


exports.list = async function (req, res) {
    try {
        const entries = await Model.findAll({
            order: [['updatedAt', 'DESC']],
            include: [
                {
                    model: profileModel,
                    as: 'profile'
                },
                {
                    model: profileModel,
                    as: 'maker'
                },
                {
                    model: profileModel,
                    as: 'checker'
                }, profilehistoryModel, loanhistoryModel, loanModel, investmentModel, repaymenthistoryModel]
        });
        res.send(entries || null);
    } catch (err) {
        res.status(500).send(err);
    }
};

exports.pendinglist = async function (req, res) {
    try {
        const entries = await Model.findAll({
            where: { status: [0] },
            order: [['updatedAt', 'DESC']],
            include: [{
                model: profileModel,
                as: 'profile'
            }, profilehistoryModel, loanhistoryModel, loanModel, investmentModel, repaymenthistoryModel]
        });
        res.send(entries || null);
    } catch (err) {
        res.status(500).send(err);
    }
};


exports.update = async function (req, res) {
    try {
        const result = await Model.findByPk(req.body.id);
        const resp = await result.update(req.body);

        switch (req.body.type) {
            case 'Profile':
                const profileHistoryResult = await profilehistoryModel.findByPk(req.body.profilehistory_id);
                await profileHistoryResult.update({ status: req.body.status });

                if (req.body.status === 2) {
                    const profileResult = await profileModel.findByPk(req.body.profile_id);
                    await profileResult.update(profileHistoryResult.dataValues);
                }
                break;
            case 'Loan':
                const loanHistoryResult = await loanhistoryModel.findByPk(req.body.loanhistory_id);
                await loanHistoryResult.update({ status: req.body.status });

                // if (req.body.status === 2) {
                const loanResult = await loanModel.findByPk(req.body.loan_id);
                await loanResult.update({ status: req.body.status });
                // }
                break;
            case 'Investment':
                const investmentResult = await investmentModel.findByPk(req.body.investment_id);
                await investmentResult.update({ status: req.body.status });
                break;
            case 'Repayment':
                const repaymentResult = await repaymenthistoryModel.findByPk(req.body.repaymenthistory_id);
                await repaymentResult.update({ status: req.body.status });
                if (req.body.status === 2 && (repaymentResult.close == 1)) {
                    const loanResult = await loanModel.findByPk(req.body.repaymenthistory.loan_id);
                    await loanResult.update({ status: 3, principle: repaymentResult.principle });
                }
                else if (req.body.status === 2) {
                    const loanResult = await loanModel.findByPk(req.body.repaymenthistory.loan_id);
                    await loanResult.update({ status: req.body.status, principle: repaymentResult.principle });
                }
                break;
            default:
                break;
        }

        res.send(resp);
    } catch (err) {
        res.status(500).send(err);
    }
};